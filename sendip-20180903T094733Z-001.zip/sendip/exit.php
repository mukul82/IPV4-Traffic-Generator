<?php
shell_exec("killall");
echo"User interupt the continuation";
header('refresh:1, URL ="sendip1.html"');
?>
